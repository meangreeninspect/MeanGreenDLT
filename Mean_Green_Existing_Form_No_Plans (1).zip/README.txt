MEAN GREEN EXISTING FORM — NO CONSTRUCTION PLANS

This is the existing working Mean Green duct leakage form with only these targeted changes:
- Construction Plans upload removed
- Construction Plans checklist requirement removed
- Construction Plans PDF merge removed
- Final report order is now:
  1. Duct Leakage Report
  2. DG Manometer Photo
  3. Test Results App Export

GITHUB UPDATE
1. Open the MeanGreenDLT repository.
2. Click Add file > Upload files.
3. Upload ONLY this new index.html.
4. Allow GitHub to replace the existing index.html.
5. Commit changes.
6. Wait 1–2 minutes for GitHub Pages to redeploy.
